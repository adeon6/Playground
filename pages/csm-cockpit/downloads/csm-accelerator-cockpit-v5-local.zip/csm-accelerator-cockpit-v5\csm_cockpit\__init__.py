"""CSM Accelerator Cockpit package."""

